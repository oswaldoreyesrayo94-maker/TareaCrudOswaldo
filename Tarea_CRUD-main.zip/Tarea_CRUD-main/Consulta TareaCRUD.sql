INSERT INTO `clientes` (`NOMBRE`, `APELLIDO`, `FOTO`) VALUES ('l', 'll', 's');
UPDATE `clientes` SET `NOMBRE`='g', `APELLIDO`='gg', `FOTO`='t' WHERE  `ID`=1;
DELETE FROM `clientes` WHERE  `ID`=1;
SELECT * FROM `clientes` LIMIT 1000;
