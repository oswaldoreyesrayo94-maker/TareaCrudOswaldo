﻿using Capa_Entidad;
using MySql.Data.MySqlClient; //libreria de MySql
using System.Data; //importacion de la capa entidad

namespace Capa_Datos
{
    public class CDCLIENTES
    {
        //variable para cumplir los parametros para que visual studio se conecte a mysql
        string CadenaConexion = "Server=localhost;User=root;Password=123456;Port=3306;database=tarea_crudbd"; // variable tipo string para conectar a la base de datos
             
        //metodo de public void 
        public void PruebaConexion()
        {
            MySqlConnection mySql = new MySqlConnection(CadenaConexion); //variable del tipo conexion se crea para probar la conexion a la base de datos

            try // fuuncion para probar 
            {
                mySql.Open(); // operacion a probar 
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al conectarse" + ex.Message); //mensaje que se devolvera si hay una mala conexion y cual es el error
                return; 
            }

            mySql.Close();
            MessageBox.Show("Conectado"); //mensaje de conectado
        }

        public void Crear(CECLIENTES ce) //metodo para crear comando de insersion de datos
        {
            MySqlConnection mySql = new MySqlConnection(CadenaConexion); //variable para conectar a la base de datos
            mySql.Open(); //para abrir conexion
            string Query = "INSERT INTO `clientes` (`NOMBRE`, `APELLIDO`, `FOTO`) VALUES ('"+ ce.NOMBRE + "', '"+ ce.APELLIDO + "', '"+ MySql.Data.MySqlClient.MySqlHelper.EscapeString(ce.FOTO) +"');"; //cadena de caracteres para insertar un query
            MySqlCommand mySql1 = new MySqlCommand(Query, mySql); //nuevo tipo de variable para hacer la ejecucion
            mySql1.ExecuteNonQuery(); //se usa este evento ya que son ejecuciones que no devuelve ningun tipo de valor su utilidad solo es para insertar
            mySql.Close(); //para cerrar conexion
            MessageBox.Show("Registro Creado");//mensaje para confirmar si se ha creado un registro
        }

        public void Editar(CECLIENTES ce) //metodo para crear comando de actualizaciobn de datos
        {
            MySqlConnection mySql = new MySqlConnection(CadenaConexion); //variable para conectar a la base de datos
            mySql.Open(); //para abrir conexion
            string Query = "UPDATE `clientes` SET `NOMBRE`= '"+ ce.NOMBRE + "', `APELLIDO`= '"+ ce.APELLIDO + "', `FOTO`= '"+ MySql.Data.MySqlClient.MySqlHelper.EscapeString(ce.FOTO) + "' WHERE  `ID`= "+ce.ID +";";//cadena de caracteres para editar un query
            MySqlCommand mySql1 = new MySqlCommand(Query, mySql); //nuevo tipo de variable para hacer la ejecucion
            mySql1.ExecuteNonQuery(); //se usa este evento ya que son ejecuciones que no devuelve ningun tipo de valor su utilidad solo es para insertar
            mySql.Close(); //para cerrar conexion
            MessageBox.Show("Registro Actualizado");//mensaje para confirmar si se ha creado un registro
        }

        public void Eliminar(CECLIENTES ce) //metodo para crear comando de eliminacion de datos
        {
            MySqlConnection mySql = new MySqlConnection(CadenaConexion); //variable para conectar a la base de datos
            mySql.Open(); //para abrir conexion
            string Query = "DELETE FROM `clientes` WHERE  `ID`=" + ce.ID + ";";//cadena de caracteres para eliminar un query
            MySqlCommand mySql1 = new MySqlCommand(Query, mySql); //nuevo tipo de variable para hacer la ejecucion
            mySql1.ExecuteNonQuery(); //se usa este evento ya que son ejecuciones que no devuelve ningun tipo de valor su utilidad solo es para insertar
            mySql.Close(); //para cerrar conexion
            MessageBox.Show("Registro Eliminado");//mensaje para confirmar si se ha creado un registro
        }

        public DataSet Listar() // metodo para listar las consultas de la base de datos
        {
            MySqlConnection mySql = new MySqlConnection(CadenaConexion); //variable para conectar a la base de datos
            mySql.Open(); //para abrir conexion
            string Query = "SELECT * FROM `clientes` LIMIT 1000;";//cadena de caracteres para seleccionar todas las consultas
            MySqlDataAdapter Adaptador; 
            DataSet dataset = new DataSet();

            Adaptador = new MySqlDataAdapter(Query, mySql); // esta linea ejecuta el query directamente
            Adaptador.Fill(dataset, "tbl"); //el adaptador hace un llenado dentro del dataset para evitar errores de sintaxis que puedan ocurrir entre MySql y VisualStudio
            
            return dataset;

        }
    } 
}
