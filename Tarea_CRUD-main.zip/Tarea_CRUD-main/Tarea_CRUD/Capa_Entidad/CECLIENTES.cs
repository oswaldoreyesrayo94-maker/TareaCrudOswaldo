﻿namespace Capa_Entidad
{
    public class CECLIENTES
    {
        //Los mismos campos que se usaron en la base de datos se usaran en la clase de entidad
       
        public int ID { get; set; } //Propiedad de numero para el ID de la capa entidad
        public string NOMBRE { get; set; } //Propiedad de cadena de caracteres para el NOMBRE de la capa entidad
        public string APELLIDO { get; set; } //Propiedad de cadena de caracteres para el APELLIDO de la capa entidad
        public string FOTO { get; set; } //Propiedad de cadena de caracteres para la FOTO de la capa entidad

        //Entidad Cliente finalizada
    }
}
