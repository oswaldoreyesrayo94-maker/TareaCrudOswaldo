﻿using Capa_Entidad; //en la capa de negocio se hace uso de la capa entidad
using Capa_Datos; //importacion de la cpa de datos
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Data;

namespace Capa_Negocio
{
    public class CNCLIENTES
    {
        CDCLIENTES cDCLIENTES = new CDCLIENTES(); //variable global para poder acceder al metodo de conexion 

        public bool Validar_Datos(CECLIENTES clientes) // metodo que retorno un valor de tipo boleano  con el parametro CECLIENTES y una variable clientes
        {
            bool Resultado = true; //variable boleana para retornar

            //validaciones para que los campos estan llenos

            if (clientes.NOMBRE == string.Empty) // operacion que indica que si no se introdujo un nombre entre en el ciclo
            {
                Resultado = false; //cambio de valor en la varible boleana
                MessageBox.Show("El nombre es obligatorio"); // mensaje de advertencia de que no se escribio un nombre
            }

            if (clientes.APELLIDO == string.Empty) // operacion que indica que si no se introdujo un apellido entre en el ciclo
            {
                Resultado = false;
                MessageBox.Show("El apellido es obligatorio"); // mensaje de advertencia de que no se escribio un apellido
            }

            if (clientes.FOTO == null) // operacion que indica que si no se introdujo una foto entre en el ciclo
            {
                Resultado = false;
                MessageBox.Show("La foto es obligatorio"); // mensaje de advertencia de que no se selecciono una foto
            }

            return Resultado; //retorno de la variable Resultado
        }

        public void PruebaMySql() //metodo para probar la conexion de la cpa de datos
        {
            cDCLIENTES.PruebaConexion(); //metodo prueba conexion 
        }

        public void CrearCliente(CECLIENTES CE) //metodo para crear registros de clientes
        {
            cDCLIENTES.Crear(CE); //metodo crear con llamado a la variable CE
            
        }
        public void EditarCliente(CECLIENTES CE) //metodo para editar registros de clientes
        {
            cDCLIENTES.Editar(CE); //metodo editar con llamado a la variable CE

        }
        public void EliminarCliente(CECLIENTES CE) //metodo para eliminar registros de clientes
        {
            cDCLIENTES.Eliminar(CE); //metodo eliminar con llamado a la variable CE

        }
        public DataSet ObtenerDatos() 
        {
            return cDCLIENTES.Listar();
        }
    }
}
