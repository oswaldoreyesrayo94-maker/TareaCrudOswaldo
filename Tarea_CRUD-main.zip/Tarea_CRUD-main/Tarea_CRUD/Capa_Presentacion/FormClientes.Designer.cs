﻿namespace Capa_Presentacion
{
    partial class FormClientes
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtNOMBRE = new TextBox();
            txtAPELLIDO = new TextBox();
            txtID = new NumericUpDown();
            lnkFOTO = new LinkLabel();
            picFOTO = new PictureBox();
            ofdFOTO = new OpenFileDialog();
            btnNUEVO = new Button();
            btnELIMINAR = new Button();
            btnGUARDAR = new Button();
            GRIDDATOS = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)txtID).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picFOTO).BeginInit();
            ((System.ComponentModel.ISupportInitialize)GRIDDATOS).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(20, 25);
            label1.Name = "label1";
            label1.Size = new Size(18, 15);
            label1.TabIndex = 0;
            label1.Text = "ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(20, 84);
            label2.Name = "label2";
            label2.Size = new Size(56, 15);
            label2.TabIndex = 1;
            label2.Text = "NOMBRE";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(20, 142);
            label3.Name = "label3";
            label3.Size = new Size(60, 15);
            label3.TabIndex = 2;
            label3.Text = "APELLIDO";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(282, 25);
            label4.Name = "label4";
            label4.Size = new Size(35, 15);
            label4.TabIndex = 3;
            label4.Text = "FOTO";
            // 
            // txtNOMBRE
            // 
            txtNOMBRE.Location = new Point(121, 81);
            txtNOMBRE.Name = "txtNOMBRE";
            txtNOMBRE.Size = new Size(130, 23);
            txtNOMBRE.TabIndex = 4;
            // 
            // txtAPELLIDO
            // 
            txtAPELLIDO.Location = new Point(121, 139);
            txtAPELLIDO.Name = "txtAPELLIDO";
            txtAPELLIDO.Size = new Size(130, 23);
            txtAPELLIDO.TabIndex = 5;
            // 
            // txtID
            // 
            txtID.Enabled = false;
            txtID.Location = new Point(121, 23);
            txtID.Name = "txtID";
            txtID.Size = new Size(70, 23);
            txtID.TabIndex = 6;
            // 
            // lnkFOTO
            // 
            lnkFOTO.AutoSize = true;
            lnkFOTO.Location = new Point(329, 165);
            lnkFOTO.Name = "lnkFOTO";
            lnkFOTO.Size = new Size(83, 15);
            lnkFOTO.TabIndex = 7;
            lnkFOTO.TabStop = true;
            lnkFOTO.Text = "SELECCIONAR";
            lnkFOTO.LinkClicked += lnkFOTO_LinkClicked;
            // 
            // picFOTO
            // 
            picFOTO.BackColor = Color.MediumAquamarine;
            picFOTO.Location = new Point(282, 47);
            picFOTO.Name = "picFOTO";
            picFOTO.Size = new Size(130, 115);
            picFOTO.SizeMode = PictureBoxSizeMode.StretchImage;
            picFOTO.TabIndex = 8;
            picFOTO.TabStop = false;
            // 
            // ofdFOTO
            // 
            ofdFOTO.FileName = "openFileDialog1";
            // 
            // btnNUEVO
            // 
            btnNUEVO.Location = new Point(20, 199);
            btnNUEVO.Name = "btnNUEVO";
            btnNUEVO.Size = new Size(75, 23);
            btnNUEVO.TabIndex = 9;
            btnNUEVO.Text = "NUEVO";
            btnNUEVO.UseVisualStyleBackColor = true;
            btnNUEVO.Click += btnNUEVO_Click;
            // 
            // btnELIMINAR
            // 
            btnELIMINAR.Location = new Point(202, 199);
            btnELIMINAR.Name = "btnELIMINAR";
            btnELIMINAR.Size = new Size(75, 23);
            btnELIMINAR.TabIndex = 10;
            btnELIMINAR.Text = "ELIMINAR";
            btnELIMINAR.UseVisualStyleBackColor = true;
            btnELIMINAR.Click += btnELIMINAR_Click;
            // 
            // btnGUARDAR
            // 
            btnGUARDAR.Location = new Point(121, 199);
            btnGUARDAR.Name = "btnGUARDAR";
            btnGUARDAR.Size = new Size(75, 23);
            btnGUARDAR.TabIndex = 11;
            btnGUARDAR.Text = "GUARDAR";
            btnGUARDAR.UseVisualStyleBackColor = true;
            btnGUARDAR.Click += btnGUARDAR_Click;
            // 
            // GRIDDATOS
            // 
            GRIDDATOS.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            GRIDDATOS.Location = new Point(20, 271);
            GRIDDATOS.Name = "GRIDDATOS";
            GRIDDATOS.Size = new Size(491, 253);
            GRIDDATOS.TabIndex = 12;
            GRIDDATOS.CellDoubleClick += GRIDDATOS_CellDoubleClick;
            // 
            // FormClientes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(523, 536);
            Controls.Add(GRIDDATOS);
            Controls.Add(btnGUARDAR);
            Controls.Add(btnELIMINAR);
            Controls.Add(btnNUEVO);
            Controls.Add(picFOTO);
            Controls.Add(lnkFOTO);
            Controls.Add(txtID);
            Controls.Add(txtAPELLIDO);
            Controls.Add(txtNOMBRE);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FormClientes";
            Text = "CLIENTES";
            Load += FormClientes_Load;
            ((System.ComponentModel.ISupportInitialize)txtID).EndInit();
            ((System.ComponentModel.ISupportInitialize)picFOTO).EndInit();
            ((System.ComponentModel.ISupportInitialize)GRIDDATOS).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtNOMBRE;
        private TextBox txtAPELLIDO;
        private NumericUpDown txtID;
        private LinkLabel lnkFOTO;
        private PictureBox picFOTO;
        private OpenFileDialog ofdFOTO;
        private Button btnNUEVO;
        private Button btnELIMINAR;
        private Button btnGUARDAR;
        private DataGridView GRIDDATOS;
    }
}
