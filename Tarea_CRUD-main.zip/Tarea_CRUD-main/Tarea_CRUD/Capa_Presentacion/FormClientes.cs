using Capa_Datos; // importacion de la capa datos
using Capa_Entidad; //importacion de la capa entidad
using Capa_Negocio; //importacion de la capa negocio

namespace Capa_Presentacion
{
    public partial class FormClientes : Form
    {
        //Definir variable global que permitira que se use dentro de cualquier metodo

        CNCLIENTES NCLIENTES = new CNCLIENTES(); //variable para referenciar la clase CNCLIENTES
        public FormClientes()
        {
            InitializeComponent();
        }

        private void btnNUEVO_Click(object sender, EventArgs e)
        {
            LimpiarForm(); //llamada del metodo de LimpiarForm para hacer una limpieza de informacion
        }



        private void LimpiarForm()
        {
            // metodo para limpiar la informacion se igualaran los elementos a valores vacios para el vaciado

            txtID.Value = 0; //la propiedad id al no ser un textbox no funcionara con el evento de text por lo tanto se usara el evento value

            // se igualan los elementos creados a a un string vacio para que se limpie
            txtNOMBRE.Text = string.Empty;
            txtAPELLIDO.Text = string.Empty;

            picFOTO.Image = null;//se usara la propiedad image para el elemento de picFOTO

        }



        private void lnkFOTO_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //metodo para que se pueda seleccionar una imagen a traves del enlace de SELECCIONAR

            ofdFOTO.FileName = string.Empty; //operacion para que se inicie totalmente vacio la opcion

            //operacion para mostrar cuadro de seleccion de imagen

            //condicional para aseguararse de que se selecciono una imagen
            if (ofdFOTO.ShowDialog() == DialogResult.OK)
            {
                //operacion para cargar imagen seleccionada
                picFOTO.Load(ofdFOTO.FileName);
            }

            ofdFOTO.FileName = string.Empty; //volver el FileName a una cadena vacia al terminar la operacion
        }

        private void btnGUARDAR_Click(object sender, EventArgs e)
        {
            //es necesario el importar o usar la referencia de capa la entidad para este boton de guardar

            //definicion de variable tipo de dato CECLIENTES y creacion de instancia eCLIENTES para acceder a las propiedades creadas en la capa de entidad del cliente
            CECLIENTES eCLIENTES = new CECLIENTES();

            bool Resultado; //variable para devolver booleano

            //asignar valores

            eCLIENTES.ID = (int)txtID.Value; // para la propiedad ID se le asignara lo que hay en el elemento txtID con parseo de int ya que el evento value es un decimal y se esta guardando un entero
            eCLIENTES.NOMBRE = txtNOMBRE.Text;// para la propiead de NOMBRE y APELLIDO se les asignara lo que hay en las txtNOMBRE y txtAPELLIDO
            eCLIENTES.APELLIDO = txtAPELLIDO.Text;
            eCLIENTES.FOTO = picFOTO.ImageLocation;//para la propiedad de FOTO se usa una ImageLocation que es la ruta donde esta la imagen la la picFOTO

            Resultado = NCLIENTES.Validar_Datos(eCLIENTES); //uso de la variable local para validar datos

            //condicional para validar si se inserto  y en caso de que no pedir que ya no se ejecute mas
            if (Resultado == false)
            {
                return;
            }

            //condicional para verificar si se esta guardando un registro existente o uno nuevo
            if (eCLIENTES.ID == 0)
            {
                NCLIENTES.CrearCliente(eCLIENTES);  //llamado al metodo de insercion de datos
            }
            else
            {
                NCLIENTES.EditarCliente(eCLIENTES); // llamado al metodo de editar los de datos
            }


            
            
            CargarDatos();//llamado al metodo de CargarDatos

        }

        private void btnELIMINAR_Click(object sender, EventArgs e)
        {
            //metodo eliminado porque ya se hizo la prueba de conexion a la base de datos
            // NCLIENTES.PruebaMySql(); //para probar la conexion se usa el boton de eliminar

            //primera condicion if que se utilizara para regresar a la modalidad de nuevo

            if (txtID.Value == 0) return;

            //segunda condicion if que se utilizara para confirma o rechazar la eliminacion de un elemento

            if (MessageBox.Show("�Quieres ELIMINAR el registro?","Titulo", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) //esta condicion pregunta si el usuario quiere eliminar un registro y se le dara las opciones en pantalla con un cuadro de si o no y un icono de interrogante y si el usuario le da en el icono de si entrara en el ciclo
            {
                CECLIENTES cE = new CECLIENTES(); //creacion de una variable de dato del tipo CECLIENTES para poder usar la funcion de eliminar
                cE.ID = (int)txtID.Value; // informacion del elemento ID insertada en la variable hecha para acceder a la nformacion del campo ID
                NCLIENTES.EliminarCliente(cE); //metodo de eliminar con el parametro de la variable creada
                
                CargarDatos(); //metodo para refrescar el formulario y se puedan vizualizar los cambios
                LimpiarForm(); //llamada del metodo de LimpiarForm para hacer una limpieza de informacion



            }

        }

        private void FormClientes_Load(object sender, EventArgs e)
        {

            CargarDatos(); //llamado al metodo de CargarDatos

        }

        //creacion de metodo para cargar los datos
        private void CargarDatos()
        {
            //evento al iniciar formulario se le hara llamada al metodo de ObtenerDatos
            GRIDDATOS.DataSource = NCLIENTES.ObtenerDatos().Tables["tbl"];
        }

        private void GRIDDATOS_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            txtID.Value = (int)GRIDDATOS.CurrentRow.Cells["ID"].Value; //operacion para que al darle doble click al campo este se pueda modificar
            txtNOMBRE.Text = GRIDDATOS.CurrentRow.Cells["NOMBRE"].Value.ToString();
            txtAPELLIDO.Text = GRIDDATOS.CurrentRow.Cells["APELLIDO"].Value.ToString();
            picFOTO.Load(GRIDDATOS.CurrentRow.Cells["FOTO"].Value.ToString());

        }
    }
}
